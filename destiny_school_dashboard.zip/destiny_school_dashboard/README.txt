DESTINY EDUCATIONAL CENTER KIMOGORO — Dashboard

Contents:
- dashboard.html: The school management dashboard HTML and embedded CSS.

How to open:
1. Extract the ZIP file.
2. Open the extracted folder in VS Code.
3. Open dashboard.html.
4. In VS Code, use Live Server if installed, or open dashboard.html directly in your browser.

Note:
This is a static HTML page. Navigation buttons and links using href="#" are placeholders and do not yet connect to working features.
